import java.util.Scanner;

public class doex2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int codigo, preco, quant, valorLote=0;
        int produto=0, uniRecebidas=0, maior=0, valorTotal=0;
        String nome, nomeMaior, c;
    

        do {
            System.out.print("Código do produto: ");
            codigo = scanner.nextInt();

            System.out.print("Nome: ");
            nome = scanner.next();
            nomeMaior=nome;

            System.out.print("Preço unitário: ");
            preco = scanner.nextInt();

            System.out.print("Quantidade recebida: ");
            quant = scanner.nextInt();

            valorLote= preco*quant;

            System.out.println(" ");
            System.out.println("Valor total do lote: R$"+valorLote);
            if (valorLote>maior){
                maior=valorLote;
                nomeMaior=nome;
            }
            produto++;
            uniRecebidas+=quant;
            valorTotal+=valorLote;
            System.out.println("Deseja cadastrar outro produto (S/N)?");
            c = scanner.next().toUpperCase();
        } while ("S".equals(c));
        System.out.println(" ");
        System.out.println("Quantidade total de produtos cadastrados: "+produto);
        System.out.println("Quantidade total de unidades recebidas: "+uniRecebidas);
        System.out.println("Valor total de todos os lotes cadastrados: R$"+valorTotal);
        System.out.println(nomeMaior+" apresentou o maior valor de lote: R$"+maior);
        System.out.println("Fim");
        scanner.close();
    }
}
