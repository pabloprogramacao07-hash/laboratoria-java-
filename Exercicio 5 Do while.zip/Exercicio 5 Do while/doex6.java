
import java.util.Scanner;

public class doex6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int op;
        float temp, resultado=0;
        String c="N";

        do{
            System.out.println("===== CONVERSOR DE TEMPERATURAS =====");
            System.out.println(" ");
            System.out.println("1 - Celsius para Fahrenheit");
            System.out.println("2 - Fahrenheit para Celsius");
            System.out.println("3 - Celsius para Kelvin");
            System.out.println("4 - Kelvin para Celsius");
            System.out.println("5 - Encerrar");
            op = scanner.nextInt();

            System.out.println("Digite a temp: ");
            temp = scanner.nextFloat();

            switch (op) {
                case 1:
                    resultado= temp*9/5+32;
                    break;
                case 2:
                    resultado=(temp-32)*5/9;
                    break;
                case 3:
                    resultado = (float) (temp + 273.15);
                    break;
                case 4:
                    resultado= (float) (temp - 273.15);
                    break;
                case 5:
                    System.out.println("Deseja realmente encerrar (S/N)?");
                    c = scanner.next().toUpperCase();
                    break;
                default:
                    System.out.println("Opção invalida");;
            }
            System.out.println("Convertido fica: "+ resultado);
            

        }while ("N".equals(c));
        System.out.println("Fim");
        scanner.close();
    }
}