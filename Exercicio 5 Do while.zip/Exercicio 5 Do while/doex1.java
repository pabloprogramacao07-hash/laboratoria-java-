
import java.util.Scanner;

public class doex1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n1, n2, op, resultado=0;
        String c;
        do{
            System.out.print("Digite o primeiro valor: ");
            n1 = scanner.nextInt();
            System.out.print("Digite o segundo valor: ");
            n2 = scanner.nextInt();
            System.out.println(" Operações matemáticas");
            System.out.println("1 - Soma");
            System.out.println("2 - Subtração");
            System.out.println("3 - Multiplicação");
            System.out.println("4 - Divisão");
            op = scanner.nextInt();

            switch (op) {
                case 1:
                    resultado= n1+n2;
                    break;
                case 2:
                    resultado=n1-n2;
                    break;
                case 3:
                    resultado=n1*n2;
                    break;
                case 4:
                    if(n2==0){
                        System.out.println("Não pode ser divisivel por 0");
                        resultado=0;
                    }
                    else{
                        resultado= n1/n2;
                    }
                    break;
                default:
                    System.out.println("Opção invalida");
            }
            System.out.println("Resultado: "+resultado);
            System.out.println("Deseja realizar outro cálculo (S/N)?");
            c=scanner.next().toUpperCase();
        }while("S".equals(c));
        System.out.println("FIM");
        scanner.close();
    }
}
