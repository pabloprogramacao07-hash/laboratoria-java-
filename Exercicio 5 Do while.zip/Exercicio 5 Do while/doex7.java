
import java.util.Scanner;

public class doex7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int op, ana=0, bruno=0, carlos=0, branco=0, nulo=0;
        int quant=0;
        float percentualAna=0, percentualBruno=0, percentualCarlos=0, valido=0;
        String c;
        c = "S";
        do { 
            System.out.println("1 - Ana");
            System.out.println("2 - Bruno");
            System.out.println("3 - Carlos");
            System.out.println("4 - Voto em branco");
            System.out.println("5 - Voto nulo");
            op = scanner.nextInt();

            quant++;

            switch (op) {
                case 1:
                    ana++;
                    valido++;
                    break;
                case 2:
                    bruno++;
                    valido++;
                    break;
                case 3:
                    carlos++;
                    valido++;
                    break;
                case 4:
                    branco++;
                    break;
                case 5:
                    nulo++;
                    break;
                default:
                    System.out.println("Opção invalida");
            }





            System.out.println("Existe outro eleitor para votar (S/N)?");
            c = scanner.next().toUpperCase();
        } while ("S".equals(c));

        if(ana>0){
            percentualAna=(float)(ana/valido)*100;
        }
        if(bruno>0){
            percentualBruno=(float)(bruno/valido)*100;
        }
        if(carlos>0){
            percentualCarlos=(float)(carlos/valido)*100;
        }
        System.out.println("Votos Ana: "+ana);
        System.out.println("Votos Bruno: "+bruno);
        System.out.println("Votos Carlos: "+carlos);
        System.out.println("Votos Brancos: "+branco);
        System.out.println("Votos Nulos: "+nulo);
        System.out.println("Total de eleitores: "+quant);
        System.out.println("Percentual Ana: "+percentualAna);
        System.out.println("Percentual bruno: "+percentualBruno);
        System.out.println("Percentual Carlos: "+percentualCarlos);

        if(ana>carlos&&ana>bruno){
            System.out.println("Ana venceu");
        }
        else if(carlos>ana&&carlos>bruno){
            System.out.println("Carlos venceu");
        }
        else if(bruno>carlos&&bruno>carlos){
            System.out.println("Bruno venceu");
        }
        else{
            System.out.println("Terminou em Empate");
        }
    }
}
