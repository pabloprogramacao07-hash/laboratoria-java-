
import java.util.Scanner;

public class doex5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int op, total=0, pessimo=0, ruim=0, regular=0, bom=0, excelente=0;
        float media, porBom, porEx;
        String c;
        do {
            System.out.println("1 - Péssimo");
            System.out.println("2 - Ruim");
            System.out.println("3 - Regular");
            System.out.println("4 - Bom");
            System.out.println("5 - Excelente");
            op = scanner.nextInt();

            switch (op) {
                case 1:
                    pessimo++;
                    break;
                case 2:
                    ruim++;
                    break;
                case 3:
                    regular++;
                    break;
                case 4:
                    bom++;
                    break;
                case 5:
                    excelente++;
                    break;
                default:
                    System.out.println("Opção invalida");
            }
            total++;


            System.out.println("Deseja registrar a avaliação de outro cliente (S/N)?");
            c = scanner.next().toUpperCase();
        } while ("S".equals(c));

        media=(pessimo+ruim+regular+bom+excelente)/total;
        porBom=100*(total*(bom/100));
        porEx=100*(total*(excelente/100));

        System.out.println("Total de participantes: "+total);
        System.out.println("Péssimo: "+pessimo);
        System.out.println("Ruim: "+ruim);
        System.out.println("Regular: "+regular);
        System.out.println("Bom: "+bom);
        System.out.println("Excelente: "+excelente);
        System.out.println("Percentual de avaliações Bom: "+porBom+"%");
        System.out.println("Percentual de avaliações Excelente: "+porEx+"%");
        System.out.println("Média das notas atribuídas: "+media);
        System.out.println("Fim");
        scanner.close();
    }
}