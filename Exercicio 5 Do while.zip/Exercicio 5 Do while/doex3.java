import java.util.Scanner;

public class doex3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int op;
        float litro, valor=0, valorF=0;
        String des="0%", tipo=null, c;

        do{
            System.out.println("1 - Gasolina - R$ 6,20/litro");
            System.out.println("2 - Etanol - R$ 4,30/litro");
            System.out.println("3 - Diesel - R$ 6,00/litro");
            op = scanner.nextInt();
            System.out.println(" ");
            System.out.print("Quantos litros: ");
            litro = scanner.nextFloat();

            switch (op) {
                case 1:
                    valor = (float) (litro*6.20);
                    tipo="Gasolina";
                    break;
                case 2:
                    valor = (float) (litro*4.30);
                    tipo="Etanol";
                    break;
                case 3:
                    valor = (float) (litro*6.00);
                    tipo="Diesel";
                    break;
                default:
                    System.out.println("Opção invalida");
            }
            if(litro>40){
                valorF=(float) (valor-(valor*0.05));
                des="5%";
            }
            else{
                valorF=valor;
            }
            System.out.println("======================================");
            System.out.println("Combustível escolhido: "+tipo);
            System.out.println("Quantidade de litros: "+litro);
            System.out.println("Valor bruto: R$"+valor);
            System.out.println("Desconto: "+des);
            System.out.println("Valor final: R$"+valorF);
            System.out.println("Deseja simular outro abastecimento (S/N)?");
            c = scanner.next().toUpperCase();
        } while ("S".equals(c));
        System.out.println("Fim");
        scanner.close();
    }
}
