
import java.util.Scanner;

public class doex4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int op, quant,quantTotal=0, pedidos=0;
        float preco=0, total, totalCinema=0;
        String c;

        do { 
            System.out.println("1 - Inteira ........ R$ 40,00");
            System.out.println("2 - Meia-entrada ... R$ 20,00");
            System.out.println("3 - VIP ............ R$ 70,00");
            op = scanner.nextInt();

            System.out.print("Quantidade desejada: ");
            quant = scanner.nextInt();

            switch (op) {
                case 1:
                    preco=40;
                    break;
                case 2:
                    preco=20;
                    break;
                case 3:
                    preco=70;
                    break;
                default:
                    System.out.println("Opção invalida");
            }
            if(quant<=0){
                System.out.println("Quantidade invalida");
            }
            else{
                total=preco*quant;
                System.out.println("valor do pedido: R$"+total);
                totalCinema+=total;
                quantTotal+=quant;
                pedidos++;
            }
            System.out.println("Deseja realizar outro pedido (S/N)?");
            c = scanner.next().toUpperCase();
        } while ("S".equals(c));
        System.out.println("Quantidade de pedidos realizados: "+pedidos);
        System.out.println("Quantidade total de ingressos vendidos: "+quantTotal);
        System.out.println("Total arrecadado pelo cinema: R$"+totalCinema);
        System.out.println("Fim");
        scanner.close();
    }
}
