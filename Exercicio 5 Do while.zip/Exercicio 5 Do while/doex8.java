public class doex8 {
    
}
