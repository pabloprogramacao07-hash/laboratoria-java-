
import java.util.Scanner;

public class ex1Matriz {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int [] [] estacionamento = new int [5] [8];
        int [] maior = new int[5];
        int quantidade=0, maiorOcupado=0, setorTotalOcupado=0;
        double livre=0, ocupado=0, total=0, percentual;

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 8; j++) {
                total++;
                System.out.println("Setor: "+i+" Vaga: "+j);
                System.out.print("Digite 0-Para Livre e 1-Para Ocupada: ");
                estacionamento [i] [j] = scanner.nextInt();
                while(estacionamento [i] [j]!=0 && estacionamento [i] [j]!=1){
                    System.out.println("Invalido");
                    System.out.print("Digite 0-Para Livre e 1-Para Ocupada: ");
                    estacionamento [i] [j] = scanner.nextInt();
                }
                if(estacionamento [i] [j]==0){
                    livre++;
                }
                else{
                    ocupado++;
                }
                if(estacionamento [i] [j]==1){
                    quantidade++;
                }
            }
            maior[i]=quantidade;
            quantidade=0;
        }
        
        if(livre>0 || ocupado>0){
            percentual=(ocupado*100)/total;
        }
        else{
            if(livre==0){
                percentual=100;
            }
            else{
                percentual=0;
            }
        }

        maiorOcupado=maior[0];

        for (int i = 0; i < 5; i++) {
            if(maior[i]>maiorOcupado){
                maiorOcupado=maior[i];
            }
            if(maior[i]==8){
                setorTotalOcupado++;
            }
        }

        System.out.println("=====================================");

        System.out.println("Total de vagas livre: "+livre);
        System.out.println("Total de vagas ocupadas: "+ocupado);
        System.out.println("Percentual de ocupação: "+percentual+"%");
        
        System.out.println("Setores com maior vaga: ");
        for (int i = 0; i < 5; i++) {
            
            if(maior[i]==maiorOcupado){
                System.out.println("Setor " + (i));
            }
            
        }
        
        System.out.println("Quantidade de setores completamente ocupados: "+setorTotalOcupado);
        System.out.println(" Localização de todas as vagas disponíveis");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 8; j++) {
                if(estacionamento [i] [j]==0){
                    System.out.println("Setor: "+i+" Vaga: "+j);
                }
            }
           
        }


    }
}

