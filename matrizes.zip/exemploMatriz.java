
import java.util.Scanner;

public class exemploMatriz {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int  [] [] m = new int [2] [2];

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m.length; j++) {
                System.out.print("Digite valores: ");
                m [i] [j] = scanner.nextInt();
            }
        }
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m.length; j++) {
                System.out.println("Valor: "+ m [i] [j]);
            }
        }

    }
}
