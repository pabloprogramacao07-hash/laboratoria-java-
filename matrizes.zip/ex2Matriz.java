
import java.util.Scanner;

public class ex2Matriz {
    public static void main(String[] args) {
        Scanner scanner = new  Scanner(System.in);

        int [] [] temperaturas = new int [4] [7];
        int [] amplitude = new int  [4];

        int maiorTemp=0, menorTemp=0;
        
        for (int i = 0; i < temperaturas.length; i++) {
            for (int j = 0; j < temperaturas[i].length; j++) {
                System.out.println("Cidade "+i+" Dia "+j);
                System.out.print("Digite a temperatura: ");
                temperaturas [i] [j] = scanner.nextInt();

            }
        }

        for (int i = 0; i < temperaturas.length; i++) {
            for (int j = 0; j < temperaturas[i].length; j++) {
                maiorTemp=temperaturas [0] [0];
                menorTemp=temperaturas [0] [0];
                if(temperaturas [i] [j]>temperaturas [i] [j+1]){
                    maiorTemp=temperaturas [i] [j];
                }
                if(temperaturas [i] [j]<temperaturas [i] [j+1]){
                    menorTemp=temperaturas [i] [j+1];
                }

            }
            amplitude[i]=maiorTemp-menorTemp;
            maiorTemp=0;
            menorTemp=0;
            System.out.println("Amplitude térmica da cidade: ");
        }


    }
}
