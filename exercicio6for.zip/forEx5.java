import java.util.Scanner;

public class forEx5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int diasDisponiveis;
        float metaTotal, capacidadeInicial;

        System.out.println("Dias dispiníveis");
        diasDisponiveis = scanner.nextInt();

        System.out.println("Meta total de produtos ");
        metaTotal = scanner.nextFloat();

        System.out.println("Capacidade inicial de produção diária: ");
        capacidadeInicial = scanner.nextFloat();


        for (int c=0;c<diasDisponiveis;c++){
            
        }

    
    }
}
