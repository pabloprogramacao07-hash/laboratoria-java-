import java.util.Scanner;

public class forEx2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int rodadas, pontuacaoTotal=0, pontuacao=0, penalidade=0;
        int totalDescontato=0, bonus=0, maior=0, maiorR=0;

        System.out.println("Quantas rodadas: ");
        rodadas = scanner.nextInt();

        for(int c=1;c<=rodadas;c++){
            System.out.println("Rodada: "+c);
            System.out.print("Pontuação: ");
            pontuacao = scanner.nextInt();

            if(pontuacao<0){
                penalidade++;
                if(penalidade>1){
                    pontuacaoTotal+=pontuacao*penalidade;
                    totalDescontato+=pontuacao*penalidade;
                }
                else{
                    pontuacaoTotal+=pontuacao;
                    totalDescontato+=pontuacao;
                }
            }
            else{
                pontuacaoTotal+=pontuacao;
            }

            if(pontuacaoTotal>100){
                pontuacaoTotal+=10;
                bonus+=10;
            }
            if(c==1){
                maior=pontuacaoTotal;
            }
            
            if(pontuacaoTotal>maior){
                maiorR=c;
            }
        }
        System.out.println("=========================================================");
        System.out.println("Pontuação Final: "+pontuacaoTotal);
        System.out.println("Quantidade de penalidades: "+penalidade);
        System.out.println("Total descontado: "+totalDescontato);
        System.out.println("Quantidade de bônus: "+bonus);
        System.out.println("A rodada em que ocorreu a maior pontuação acumulada: "+maiorR);


    }
}
