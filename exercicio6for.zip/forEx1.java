
import java.util.Scanner;

public class forEx1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n1, n2, divisor=1, divide, par=0, impar=0;
        int quantEquilibrado=0;
        float teste;

        System.out.println("Digite dois números inteiros positivos, ");
        System.out.println("representando os limites inicial e final de um intervalo");
        System.out.println("Número 1: ");
        n1 = scanner.nextInt();
        System.out.println("Número 2: ");
        n2 = scanner.nextInt();

       

        for (int c = n1;c<=n2; c++) {
            
            while (divisor<c) {
                divide=c/divisor;
                
            }
            if(par == impar){
                quantEquilibrado++;
                System.out.println(c+" é equilibrado");
                System.out.println("Quantidade par: "+par);
                System.out.println("Quantidade impar: "+impar);
                
            }
            else{
                System.out.println(c+" não é equilibrado");
                System.out.println("Quantidade par: "+par);
                System.out.println("Quantidade impar: "+impar);
            }
            par=0;
            impar=0;
            divisor=1;
        }
        System.out.println("Quantidade de números equilibrados: "+quantEquilibrado);

    }
}
