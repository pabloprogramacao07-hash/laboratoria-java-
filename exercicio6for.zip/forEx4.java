import java.util.Scanner;

public class forEx4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int num, teste;
        String par, impar;

        System.out.println("Digite um número inteiro positivo: ");
        num = scanner.nextInt();

        for(int c =0; c<num;c++){
            
        }
    }
}
