import java.util.Scanner;


public class forEx3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int quanTeste=0, testeMetade=0;
        float resistenciaInicial,reAtual, resRestante=1, metade=0;
        float taxa=(float) 0.02;

        System.out.print("Quantidade de testes: ");
        quanTeste = scanner.nextInt();

        System.out.print("Resistencia inicial: ");
        resistenciaInicial = scanner.nextFloat();
        reAtual=resistenciaInicial;
        metade= reAtual/2;
        for (int c = 1; c <= quanTeste; c++) {
            if(c>1){
                taxa+=0.005;
            }
            if(c==1){
                reAtual-=reAtual*(reAtual/taxa);
                resRestante-=taxa;
            }
            else if(c<5||c>5){
                reAtual-=reAtual*(reAtual/taxa);
                resRestante-=taxa;
            }
            else if(c==5){
                reAtual-=reAtual*(reAtual/taxa);
                reAtual+=reAtual*(reAtual/0.08);
                resRestante+=taxa;
                if(reAtual>resistenciaInicial){
                    reAtual=resistenciaInicial;
                    resRestante=1;
                }
            }
            if(metade>reAtual){
                if(testeMetade==0){
                    testeMetade=c;
                }
            }
            System.out.println("====================================================");
            System.out.println("Teste: "+c);
            System.out.println("Resistência restante: "+Math.round(100*resRestante)+"%");
        }
        System.out.println("====================================================");
        System.out.println("Resistencia final: "+reAtual);
        System.out.println("Perda percentual acumulada: "+Math.round(taxa)+"%");
        if(testeMetade>0){
            System.out.println("Primeiro teste em que a resistência ficou abaixo de 50% da original: "+ testeMetade);
        }
        System.out.println("");
    }
}
